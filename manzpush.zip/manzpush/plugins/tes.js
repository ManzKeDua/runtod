const command = {
    command: ['tes'],
    category: ['main']
};

command.script = async (m, { hisoka }) => {
    m.reply("hehe")
}
    
export default command;